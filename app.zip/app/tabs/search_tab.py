import streamlit as st
import pandas as pd
import unicodedata
from matplotlib.patches import Rectangle
from mplsoccer import Pitch
import matplotlib.pyplot as plt

@st.cache_data
def load_data():
    try:
        return pd.read_csv('merged_players.csv', sep=',')
    except Exception as e:
        st.error(f"Nie udało się wczytać danych: {e}")
        return None

def normalize_string(s):
    return unicodedata.normalize('NFKD', s).encode('ASCII', 'ignore').decode('ASCII')

def draw_field(selected_position):
    pitch = Pitch(line_color="white", pitch_color="#101414")
    fig, ax = plt.subplots(figsize=(32, 20))
    pitch.draw(ax=ax)
    position_colors = {
        "DF": "yellow" if selected_position == "DF" else "lightgrey",
        "MF": "green" if selected_position == "MF" else "lightgrey",
        "FW": "blue" if selected_position == "FW" else "lightgrey"
    }
    ax.add_patch(Rectangle((10, 0), 32.5, 80, color=position_colors["DF"], alpha=0.3))
    ax.add_patch(Rectangle((42.5, 0), 32.5, 80, color=position_colors["MF"], alpha=0.3))
    ax.add_patch(Rectangle((75, 0), 32.5, 80, color=position_colors["FW"], alpha=0.3))
    st.pyplot(fig)

def render_search_tab():
    data = load_data()
    if data is None:
        st.stop()

    st.header("Wyszukiwanie zawodników")

    # Wybór sezonu
    seasons = ["Dowolny"] + list(data['season'].unique())
    season = st.selectbox("Wybierz sezon:", seasons)
    if season != "Dowolny":
        data = data[data['season'] == season]

    # Pole wyszukiwania zawodników
    search_term = st.text_input("Szukaj zawodnika po nazwisku:")

    # Opcjonalne filtrowanie ligi
    filter_league = st.checkbox("Filtruj według ligi")
    if filter_league:
        selected_leagues = st.multiselect("Wybierz ligę/ligi:", ["Premier League", "Ligue 1", "Bundesliga", "La Liga", "Serie A"])
        if selected_leagues:
            data = data[data['Comp'].isin(selected_leagues)]

    # Wybór pozycji
    position_map = {
        "Dowolna": "all",
        "Obrońca": "DF",
        "Pomocnik": "MF",
        "Napastnik": "FW"
    }
    selected_position = st.selectbox("Wybierz pozycję:", list(position_map.keys()), index=0)

    # Rysowanie boiska z zaznaczoną pozycją
    draw_field(position_map[selected_position] if selected_position != "Dowolna" else None)
    if selected_position != "Dowolna":
        data = data[data['Pos'].str.contains(position_map[selected_position], na=False)]

    # Wybór wiodącej nogi
    foot_map = {"Lewa": "left", "Prawa": "right", "Obie": "both"}
    foot = st.selectbox("Wybierz wiodącą nogę:", ["Dowolna", "Lewa", "Prawa", "Obie"])
    if foot != "Dowolna":
        data = data[data['foot'] == foot_map.get(foot)]

    # Wybór narodowości
    countries = data['Nation'].unique()
    selected_countries = st.multiselect("Wybierz narodowość:", countries)
    if selected_countries:
        data = data[data['Nation'].isin(selected_countries)]


    # Kluczowe statystyki
    st.write("### Kluczowe statystyki")
    stats = {
        "Liczba minut w sezonie": "Min",
        "Liczba goli": "Goals",
        "Liczba strzałów": "Shots",
        "Procent strzałów celnych": "SoT%",
        "Gole na strzał": "G/Sh",
        "Śr. odległość strzałów": "ShoDist",
        "Asysty": "Assists",
        "Procent celnych podań": "PasTotCmp%",
        "Procent celnych krótkich podań": "PasShoCmp%",
        "Procent celnych średnich podań": "PasMedCmp%",
        "Procent celnych długich podań": "PasLonCmp%",
        "Dryblingi": "DriAtt",
        "Udane dryblingi": "DriSucc",
        "Akcje tworzące bramkę": "GCA",
        "Dośrodkowania": "CrsPA",
        "Biegi progresywne": "CarProg",
        "Kontakty z piłką": "Touches",
        "Faule popełnione na zawodniku": "Fld",
        "Spalone": "Off",
        "Odbiory": "Rec",
        "Udane przechwyty": "Int",
        "Faule (popełnione przez zawodnika)": "Fls",
        "Żółte kartki": "CrdY",
        "Czerwone kartki": "CrdR",
        "Wygrane pojedynki powietrzne": "AerWon"
    }

    selected_stats = {}
    with st.expander("Wyświetl kluczowe statystyki", expanded=False):
        for display_name, column_name in stats.items():
            if st.checkbox(display_name, value=False):
                min_value = st.text_input(f"{display_name} (min wartość)", value="0.0")
                try:
                    selected_stats[column_name] = float(min_value)
                except ValueError:
                    selected_stats[column_name] = 0.0

    # Przycisk wyszukiwania zawodników
    if st.button("Szukaj zawodników"):
        filtered_data = data.copy()

        if search_term:
            search_term_normalized = normalize_string(search_term.lower())
            filtered_data = filtered_data[filtered_data['name'].apply(lambda x: normalize_string(str(x)).lower()).str.contains(search_term_normalized)]

        for stat, min_value in selected_stats.items():
            if stat in filtered_data.columns:
                filtered_data = filtered_data[filtered_data[stat] >= min_value]


        # Tłumaczenie kolumny "foot"
        if 'foot' in filtered_data.columns:
            filtered_data['foot'] = filtered_data['foot'].replace({"right": "prawa", "left": "lewa", "both":"obie"})

        # Zmiana kolejności kolumn, tłumaczenie nagłówków oraz ukrycie kolumny "image_url"
        if not filtered_data.empty:
            column_renames = {
                "name": "Nazwisko",
                "season": "Sezon",
                "Comp": "Liga",
                "Pos": "Pozycja",
                "foot": "Wiodąca noga",
                "Nation": "Narodowość",
                "Squad": "Drużyna",
                "Age": "Wiek",
                "height_in_cm": "Wzrost (cm)",
                "Born": "Data urodzenia",
                "MP": "Mecze rozegrane",
                "Starts": "Wyjściowe składy",
                "Min": "Minuty",
                "90s": "90min",
                "Goals": "Gole",
                "Shots": "Strzały",
                "SoT": "Strzały celne",
                "SoT%": "% celnych strzałów",
                "G/Sh": "Gole na strzał",
                "G/SoT": "Gole na celny strzał",
                "ShoDist": "Dystans strzałów",
                "ShoFK": "Strzały z rzutów wolnych",
                "ShoPK": "Gole z karnych",
                "PKatt": "Podejścia do karnych",
                "PasTotCmp": "Celne podania",
                "PasTotAtt": "Próby podań",
                "PasTotCmp%": "% celnych podań",
                "PasTotDist": "Dystans podań",
                "PasTotPrgDist": "Progresywne podania",
                "PasShoCmp": "Krótkie celne podania",
                "PasShoAtt": "Próby krótkich podań",
                "PasShoCmp%": "% krótkich podań",
                "PasMedCmp": "Średnie celne podania",
                "PasMedAtt": "Próby średnich podań",
                "PasMedCmp%": "% średnich podań",
                "PasLonCmp": "Długie celne podania",
                "PasLonAtt": "Próby długich podań",
                "PasLonCmp%": "% długich podań",
                "Assists": "Asysty",
                "PasAss": "Podania asystujące",
                "Pas3rd": "Podania w ostatnią tercję",
                # Dodaj tłumaczenia dla pozostałych kolumn według potrzeb
            }
            
            # Tłumaczenie kolumn
            filtered_data = filtered_data.rename(columns=column_renames)
            
            # Lista stałych kolumn w odpowiedniej kolejności
            fixed_columns = [
                "Nazwisko",
                "Sezon",  # Umieszczenie kolumny "Sezon" jako drugiej
                "Liga",
                "Pozycja",
                "Wiodąca noga",
                "Narodowość",
                "Drużyna",
                "Wiek"
            ]
            
            # Dodanie pozostałych kolumn poza "image_url" w oryginalnej kolejności
            additional_columns = [col for col in filtered_data.columns if col not in fixed_columns and col != "image_url" and col != "player_value"]
            columns_order = fixed_columns + additional_columns
            
            # Ustawienie kolejności kolumn
            filtered_data = filtered_data[columns_order]
            
            # Resetowanie indeksu, aby zaczynał się od 1
            filtered_data = filtered_data.reset_index(drop=True)
            filtered_data.index = filtered_data.index + 1
            
            st.write("Znalezieni zawodnicy:")
            st.dataframe(filtered_data)
        else:
            st.write("Brak wyników spełniających kryteria.")

