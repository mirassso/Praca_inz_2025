import pandas as pd
import numpy as np
from math import sqrt, pi
import streamlit as st
import matplotlib.pyplot as plt
from tabs.stats_predict_tab import predict_stats
from other.player_radar_chart import plot_radar_chart_team_fit

# Tłumaczenie metryk na język polski
metrics_mapping = {
    'Directness': 'Bezpośredniość',
    'Shot Distance': 'Odległość strzału',
    'Chance Creation': 'Tworzenie sytuacji',
    'Finishing': 'Wykończenie',
    'Long Balls': 'Długie piłki',
    'Aggresiveness': 'Agresywność',
    'Possession': 'Posiadanie piłki',
    'Control': 'Kontrola',
}


# Funkcja obliczająca odległość euklidesową między dwoma drużynami
def calculate_euclidean_distance(team1_data, team2_data, metryki):
    diff = 0
    for metryka in metryki:
        diff += (team1_data[metryka] - team2_data[metryka]) ** 2
    return sqrt(diff)

# Funkcja obliczająca dopasowanie drużyn i generująca komentarz
def ocena_dopasowania(player_name, target_team_name, short_merged, short_team):
    # Pobierz dane o zawodniku
    player_data = short_merged[short_merged['name'] == player_name]
    
    if player_data.empty:
        return "Zawodnik nie znaleziony"
    
    current_team = player_data['Squad'].values[0]
    
    # Pobierz metryki drużyn
    current_team_data = short_team[short_team['Team'] == current_team].iloc[0]
    target_team_data = short_team[short_team['Team'] == target_team_name].iloc[0]
    
    if current_team_data.empty or target_team_data.empty:
        return "Drużyna nie znaleziona"
    
    # Lista metryk
    metryki = [
        'Directness', 'Shot Distance', 'Chance Creation', 'Finishing',
        'Long Balls', 'Aggresiveness', 'Possession', 'Control'
    ]
    
    # Oblicz odległość euklidesową między drużynami
    distance = calculate_euclidean_distance(current_team_data, target_team_data, metryki)
    
    # Oblicz odległości między wszystkimi drużynami w zbiorze
    distances = []
    for idx, row in short_team.iterrows():
        team_data = row
        team_distance = calculate_euclidean_distance(current_team_data, team_data, metryki)
        distances.append(team_distance)
    
    # Oblicz minimalną i maksymalną odległość
    min_distance = min(distances)
    max_distance = max(distances)
    
    # Znormalizuj wynik do skali 1-6
    normalized_score = 6 - (distance - min_distance) / (max_distance - min_distance) * 5
    
    # Zaokrąglij wynik do dwóch miejsc po przecinku (usuwamy błąd zaokrąglenia)
    normalized_score = round(normalized_score, 2)
    
    # Zapewniamy, że wynik nie będzie poza zakresem 1-6
    normalized_score = max(1, min(normalized_score, 6))
    
    # Sprawdzenie formacji i dodanie punktów
    current_formation = current_team_data['Formation']
    target_formation = target_team_data['Formation']
    
    formation_comment = ""
    if current_formation == target_formation:
        formation_comment = f"Formacja drużyn była taka sama ({current_formation}), co może ułatwić adaptację zawodnika."
        # Dodajemy 0.5 punktu za dopasowanie formacji
        normalized_score += 0.5
        normalized_score = min(normalized_score, 6)  # Zabezpieczenie, aby wynik nie przekroczył 6

    # Zaokrąglenie ostatecznej oceny do 2 miejsc po przecinku
    normalized_score = round(normalized_score, 2)
    
    # Wybór odpowiedniego komentarza na podstawie ostatecznej oceny
    if normalized_score >= 5:
        comment = "Doskonałe dopasowanie. Zawodnik dobrze pasuje do drużyny. Przejście między drużynami o podobnym stylu gry powinno być stosunkowo płynne."
    elif normalized_score >= 4:
        comment = "Dobre dopasowanie. Zawodnik ma szansę na udany transfer, ale może napotkać pewne trudności w adaptacji do nowego stylu gry."
    elif normalized_score >= 3:
        comment = "Średnie dopasowanie. Zawodnik będzie musiał dostosować się do znaczących różnic w stylu gry drużyn."
    elif normalized_score >= 2:
        comment = "Dopasowanie poniżej oczekiwań. Zawodnikowi będzie trudno wkomponować się w drużynę o zupełnie innym stylu gry."
    else:
        comment = "Słabe dopasowanie. Styl gry drużyn jest bardzo różny, co może prowadzić do trudności w zaadaptowaniu się."
    
    return normalized_score, comment, formation_comment


# Funkcja do skalowania przewidywanych statystyk na podstawie oceny dopasowania
def scale_predictions(predictions, fit_score):
    if fit_score >= 5:
        return predictions  # Nie zmieniać, jeśli dopasowanie jest dobre
    
    # Oblicz procentowy spadek
    scaling_factor = 1 - (0.65 * (1 - (fit_score - 1) / 4))  # Zmniejszenie o maksymalnie 65% przy ocenie 1
    
    # Zastosuj skalowanie do każdej statystyki
    scaled_predictions = {metric: round(value * scaling_factor, 2) for metric, value in predictions.items()}
    return scaled_predictions

# Funkcja renderująca zakładkę z oceną dopasowania do zespołu
# Funkcja renderująca zakładkę z oceną dopasowania do zespołu
def render_team_fit_tab():
    # Wczytanie danych (załóżmy, że dane są w plikach CSV)
    short_merged = pd.read_csv("short_merged.csv")
    short_team = pd.read_csv("short_team.csv")
    
    # Wybór zawodnika i drużyny z rozwijalnych list
    player_name = st.selectbox('Wybierz zawodnika:', short_merged['name'].unique())
    target_team_name = st.selectbox('Wybierz drużynę:', short_team['Team'].unique())
    
    if st.button("Sprawdź"):
        # Oblicz wynik oceny dopasowania
        fit_score, comment, formation_comment = ocena_dopasowania(player_name, target_team_name, short_merged, short_team)
        
        # Skalowanie statystyk w zależności od dopasowania
        predictions, league_avg_values, position = predict_stats(player_name, "2023-2024")
        scaled_predictions = scale_predictions(predictions, fit_score)

        # Kolor oceny
        if fit_score >= 5:
            score_color = "green"
        elif fit_score >= 4:
            score_color = "yellowgreen"
        elif fit_score >= 3:
            score_color = "yellow"
        elif fit_score >= 2:
            score_color = "orange"
        else:
            score_color = "red"
        
        # Wyświetlanie wyniku
        st.header("Ocena")
        st.markdown(f"<h3 style='color: {score_color}; text-align: center;'>"
                    f"<span style='border: 2px solid {score_color}; border-radius: 50%; "
                    f"width: 100px; height: 100px; display: flex; align-items: center; justify-content: center; "
                    f"font-size: 24px;'>{fit_score}</span></h3>", unsafe_allow_html=True)
        
        # Komentarze
        st.subheader("Komentarz")
        st.write(comment)
        st.write(formation_comment)

        # Mapowanie metryk na język polski
        metrics_mapping_2 = {
            'Deep_Progression_M': 'Głęboka progresja',
            'Fouls_Won_M': 'Wywalczone faule',
            'Finishing_Efficiency_M': 'Skuteczność wykończenia',
            'Chance_Creation_M': 'Tworzenie szans',
            'Goal_Creation_M': 'Tworzenie akcji bramkowych',
            'Goals_M': 'Bramki',
            'Assists_M': 'Asysty',
            'Aerial_Duels_M': 'Pojedynki powietrzne',
            'Defensive_Actions_M': 'Akcje obronne',
            'Aggressiveness_M': 'Agresywność',
            'Dribbles_M': 'Dryblingi',
            'Pressure_M': 'Pressing'
        }
        
        # Wyświetlenie przeskalowanych statystyk z tłumaczeniem w rozwijalnym elemencie
        with st.expander("Przewidywane statystyki"):
            for stat, value in scaled_predictions.items():
                translated_stat = metrics_mapping_2.get(stat, stat)  # Tłumaczymy nazwę metryki
                st.write(f"**{translated_stat}:** {value}")

        season='2023-2024'
        plot_radar_chart_team_fit(player_name, season, scaled_predictions, metrics_mapping_2)