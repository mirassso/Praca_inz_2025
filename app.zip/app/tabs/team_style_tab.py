import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from mplsoccer import Pitch
from matplotlib.patches import Rectangle

@st.cache_data
def load_team_stats():
    try:
        return pd.read_csv('team_stats_scaled.csv', sep=',')
    except Exception as e:
        st.error(f"Nie udało się wczytać danych drużynowych: {e}")
        return None

def draw_field_with_stats(team_stats, team_name, season):
    pitch = Pitch(line_color="white", pitch_color="#101414")
    
    # Stworzenie dwóch osobnych boisk
    fig, axes = plt.subplots(1, 2, figsize=(20, 10))
    
    # Filtrowanie danych dla wybranego sezonu i drużyny
    season_data = team_stats[(team_stats['Season'] == season) & (team_stats['Team'] == team_name)]

    if season_data.empty:
        st.error("Brak danych dla wybranej drużyny i sezonu.")
        return

    row = season_data.iloc[0]

    # Walidacja obecności kolumn
    required_columns_attack = ['Left Side %', 'Middle %', 'Right Side %']
    required_columns_thirds = ['Own Third %', 'Middle Third %', 'Opposition Third %']
    for col in required_columns_attack + required_columns_thirds:
        if col not in team_stats.columns:
            st.error(f"Brak wymaganej kolumny: {col}")
            return

    # Pierwsze boisko: Kierunki ataku
    attack_data = {
        "Left Side %": row['Left Side %'],
        "Middle %": row['Middle %'],
        "Right Side %": row['Right Side %'],
    }
    pitch.draw(ax=axes[0])
    axes[0].set_title(f"Strony ataków: {team_name} ({season})", fontsize=16, color="black")

    # Rysowanie prostokątów na pierwszym boisku
    left_color = plt.cm.Blues(attack_data["Left Side %"] / 100)
    middle_color = plt.cm.Blues(attack_data["Middle %"] / 100)
    right_color = plt.cm.Blues(attack_data["Right Side %"] / 100)

    axes[0].add_patch(Rectangle((0, 0), 120, 25, color=left_color, alpha=0.8))
    axes[0].add_patch(Rectangle((0, 25), 120, 30, color=middle_color, alpha=0.8))
    axes[0].add_patch(Rectangle((0, 55), 120, 25, color=right_color, alpha=0.8))

    # Dodanie wartości procentowych na pierwszym boisku
    axes[0].text(60, 15, f"{attack_data['Left Side %']}%", color="white", ha="center", va="center", fontsize=30)
    axes[0].text(60, 40, f"{attack_data['Middle %']}%", color="white", ha="center", va="center", fontsize=30)
    axes[0].text(60, 65, f"{attack_data['Right Side %']}%", color="white", ha="center", va="center", fontsize=30)

    # Rysowanie strzałki wskazującej kierunek ataku
    axes[0].arrow(25, 75, 60, 0, head_width=5, head_length=10, fc='white', ec='white', alpha=0.6)

    # Drugie boisko: Tercje boiska
    position_data = {
        "Own Third %": row['Own Third %'],
        "Middle Third %": row['Middle Third %'],
        "Opposition Third %": row['Opposition Third %'],
    }
    pitch.draw(ax=axes[1])
    axes[1].set_title(f"Tercje boiska: {team_name} ({season})", fontsize=16, color="black")

    # Rysowanie prostokątów na drugim boisku
    own_color = plt.cm.Greens(position_data["Own Third %"] / 100)
    middle_third_color = plt.cm.Greens(position_data["Middle Third %"] / 100)
    opp_color = plt.cm.Greens(position_data["Opposition Third %"] / 100)

    axes[1].add_patch(Rectangle((0, 0), 40, 80, color=own_color, alpha=0.8))
    axes[1].add_patch(Rectangle((40, 0), 40, 80, color=middle_third_color, alpha=0.8))
    axes[1].add_patch(Rectangle((80, 0), 40, 80, color=opp_color, alpha=0.8))

    # Dodanie wartości procentowych na drugim boisku
    axes[1].text(20, 40, f"{position_data['Own Third %']}%", color="white", ha="center", va="center", fontsize=30)
    axes[1].text(60, 40, f"{position_data['Middle Third %']}%", color="white", ha="center", va="center", fontsize=30)
    axes[1].text(100, 40, f"{position_data['Opposition Third %']}%", color="white", ha="center", va="center", fontsize=30)

    axes[1].arrow(25, 75, 60, 0, head_width=5, head_length=10, fc='white', ec='white', alpha=0.6)

    st.pyplot(fig)

# Mapa tłumaczeń nazw cech na polski
style_column_mapping = {
    'Directness': 'Bezpośredniość',
    'Shot Distance': 'Odległość Strzału',
    'Dribbles': 'Dryblingi',
    'Fouls': 'Faule',
    'Counter Attack': 'Kontrataki',
    'Chance Creation': 'Tworzenie Sytuacji',
    'Finishing': 'Wykończenie',
    'Long Balls': 'Długie Piłki',
    'Aggresiveness': 'Agresywność',
    'Aerial Play': 'Gra w Powietrzu',
    'Possession': 'Posiadanie Piłki',
    'Control': 'Kontrola',
    'Set Pieces': 'Stałe Fragmenty Gry'
}

# Lista opisów dla suwaków
slider_labels = {
    'Directness': ('Cierpliwy', 'Bezpośredni'),
    'Shot Distance': ('Blisko', 'Daleko'),
    'Dribbles': ('Mniej', 'Więcej'),
    'Fouls': ('Mniej', 'Więcej'),
    'Counter Attack': ('Mało', 'Dużo'),
    'Chance Creation': ('Mało', 'Dużo'),
    'Finishing': ('Nieskuteczne', 'Skuteczne'),
    'Long Balls': ('Mniej', 'Więcej'),
    'Aggresiveness': ('Spokojnie', 'Agresywnie'),
    'Aerial Play': ('Słaba', 'Mocna'),
    'Possession': ('Niskie', 'Wysokie'),
    'Control': ('Defensywna', 'Ofensywna'),
    'Set Pieces': ('Mało', 'Dużo')
}

# Funkcja do rysowania suwaków stylu gry zespołu
def plot_team_sliders(team_name, season, team_stats, style_cols):
    
    season_data = team_stats[team_stats['Season'] == season] # Filtrowanie danych dla wybranego sezonu
    
    team_data = season_data[season_data['Team'] == team_name].iloc[0] # Pobieranie danych dla wybranego klubu
    
    fig, ax = plt.subplots(figsize=(12, 10))
    plt.subplots_adjust(left=0.3, right=0.9, top=0.95, bottom=0.05)
    
    y_positions = np.linspace(0, len(style_cols) - 1, len(style_cols))[::-1]
    
    # Rysowanie suwaków
    for y, col in zip(y_positions, style_cols):
        ax.plot([0, 10], [y, y], 'k--', alpha=0.3)
        
        # Rysowanie kropek dla innych drużyn z tego samego sezonu
        for _, row in season_data.iterrows():
            if row['Team'] != team_name:
                ax.plot(row[col], y, 'ko', markersize=5, alpha=0.1)
        
        # Rysowanie kropki dla wybranego klubu
        ax.plot(team_data[col], y, 'ko', markersize=10, label=team_name)
        
        # Dodanie opisów suwaków
        if col in slider_labels:
            ax.text(-0.5, y, slider_labels[col][0], va='center', ha='right', fontsize=10, color='gray')
            ax.text(10.5, y, slider_labels[col][1], va='center', ha='left', fontsize=10, color='gray')

    # Ustawienia osi
    ax.set_xlim(0, 10)  
    ax.set_ylim(-1, len(style_cols))  
    ax.set_yticks(y_positions)
    
    yticks = ax.get_yticklabels()
    for tick in yticks:
        tick.set_x(-0.2)
    
    translated_style_cols = [style_column_mapping.get(col, col) for col in style_cols]
    ax.set_yticklabels(translated_style_cols)
    
    ax.set_xticks(range(0, 11, 1))
    ax.set_title(f'Styl gry drużyny {team_name} ({season})', fontsize=14)
    
    plt.grid(axis='x', linestyle='--', alpha=0.5)
    
    # Zwrócenie wykresu
    return fig


def render_teams_style_tab():
    team_stats = load_team_stats()
    if team_stats is None:
        st.stop()

    st.header("Styl gry zespołu")

    # Zdefiniowanie dostępnych drużyn
    teams = team_stats['Team'].unique()

    # Wybór drużyny
    selected_team = st.selectbox("Wybierz drużynę:", teams)

    if selected_team:
        # Filtracja dostępnych sezonów dla wybranego klubu
        available_seasons = team_stats[team_stats['Team'] == selected_team]['Season'].unique()

        # Wybór sezonu
        selected_season = st.selectbox("Wybierz sezon:", available_seasons)

        # Wyświetlanie podstawowych informacji o drużynie
        team_info = team_stats[team_stats['Team'] == selected_team].iloc[0]
        st.subheader("Informacje o drużynie:")
        st.write(f"**Drużyna:** {team_info['Team']}")
        st.write(f"**Liga:** {team_info['League']}")
        st.write(f"**Sezon:** {team_info['Season']}")
        st.write(f"**Trener:** {team_info['Coach']}")
        st.write(f"**Formacja:** {team_info['Formation']}")
        st.write(f"**Miejsce w lidze:** {team_info['Place']}")

        # Dodanie rozwijalnych sekcji ze statystykami
        with st.expander("Statystyki drużyny:"):
            st.write(f"**Gole:** {team_info['Goals']}")
            st.write(f"**Strzały na mecz:** {team_info['Shots pg']}")
            st.write(f"**xG:** {team_info['xG']}")
            st.write(f"**Gole bez samobójczych:** {team_info['Non-OG Goals']}")
            st.write(f"**Różnica xG:** {team_info['xG Diff']}")
            st.write(f"**Strzały:** {team_info['Shots']}")
            st.write(f"**xG/Strzały:** {team_info['xG/Shots']}")
            st.write(f"**Żółte kartki:** {team_info['Yellow cards']}")
            st.write(f"**Czerwone kartki:** {team_info['Red cards']}")
            st.write(f"**Posiadanie piłki:** {team_info['Possession%']}")
            st.write(f"**Celność podań:** {team_info['Pass%']}")
            st.write(f"**Wygrane pojedynki powietrzne:** {team_info['AerialsWon']}")
            st.write(f"**Odbiory na mecz:** {team_info['Tackles pg']}")
            st.write(f"**Przechwyty na mecz:** {team_info['Interceptions pg']}")
            st.write(f"**Faule na mecz:** {team_info['Fouls pg']}")
            st.write(f"**Spalone na mecz:** {team_info['Offside pg']}")
            st.write(f"**Długie piłki na mecz:** {team_info['Long Balls pg']}")
            st.write(f"**Krótkie podania na mecz:** {team_info['Short Passes pg']}")

        # Wyświetlanie wykresu
        if selected_season:
            style_cols = [
                'Directness', 'Shot Distance', 'Dribbles', 'Fouls', 'Counter Attack',
                'Chance Creation', 'Finishing', 'Long Balls', 'Aggresiveness',
                'Aerial Play', 'Possession', 'Control', 'Set Pieces'
            ]
            fig = plot_team_sliders(selected_team, selected_season, team_stats, style_cols)
            st.pyplot(fig)
        
        # Wyświetlanie boiska z zaznaczonymi statystykami
        draw_field_with_stats(team_stats, selected_team, selected_season)
