import streamlit as st
import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib
from other.player_radar_chart import plot_radar_chart_without_average

def load_data():
    return pd.read_csv('merged_players.csv')

def calculate_age(born, prediction_year):
    return prediction_year - born

def predict_stats(player_name, season):
    # Wczytanie danych
    df = load_data()

    # Definicja sezonu i roku do obliczeń
    prediction_year = int(season.split('-')[0])

    # Filtracja danych dla wybranego zawodnika
    player_data = df[df['name'] == player_name]

    # Sprawdzenie, czy dane zawodnika są dostępne
    if player_data.empty:
        st.write(f'Brak danych dla zawodnika {player_name}')
        return None, None, None

    # Kolumny używane w modelach
    selected_columns = ['Goals', 'Assists', 'Deep_Progression_M', 'Fouls_Won_M', 'Finishing_Efficiency_M', 
                        'Chance_Creation_M', 'Goal_Creation_M', 'Aerial_Duels_M', 'Defensive_Actions_M', 
                        'Aggressiveness_M', 'Dribbles_M', 'Pressure_M', 'Goals_M', 'Assists_M', 
                        'CarProg', 'PasProg', 'Fld', 'Shots', 'SCA', 'GCA', 'AerWon', 'AerLost', 
                        'Tkl', 'TklWon', 'Int', 'Blocks', 'Recov', 'Clr', 'CrdY', 'CrdR', 
                        'DriSucc', 'DriAtt', 'TklDef3rd', 'TklMid3rd', 'TklAtt3rd', 'Age']

    # Filtracja wybranych kolumn
    player_data_selected = player_data[selected_columns].copy()

    # Obliczanie wieku zawodnika na podstawie kolumny "Born" i roku predykcji
    player_data_selected.loc[:, 'Age'] = calculate_age(player_data['Born'].values[0], prediction_year)

    # Listy cech używanych w modelach
    features_finishing = ['Goals', 'Assists', 'Deep_Progression_M', 'Fouls_Won_M', 'Chance_Creation_M', 
                          'Goal_Creation_M', 'Aerial_Duels_M', 'Defensive_Actions_M', 'Aggressiveness_M', 
                          'Dribbles_M', 'Pressure_M', 'CarProg', 'PasProg', 'Fld', 'Shots', 'SCA', 'GCA', 'Age']

    features_goals = ['Goals', 'Assists', 'Deep_Progression_M', 'Fouls_Won_M', 'Chance_Creation_M', 
                      'Goal_Creation_M', 'Aerial_Duels_M', 'Defensive_Actions_M', 'Aggressiveness_M', 'Dribbles_M', 
                      'Pressure_M', 'CarProg', 'PasProg', 'Fld', 'Shots', 'SCA', 'GCA', 'Age']

    features_assists = ['Assists', 'Goals', 'Deep_Progression_M', 'Fouls_Won_M', 'Chance_Creation_M', 
                        'Goal_Creation_M', 'Aerial_Duels_M', 'Defensive_Actions_M', 'Aggressiveness_M', 'Dribbles_M', 
                        'Pressure_M', 'CarProg', 'PasProg', 'Fld', 'Shots', 'SCA', 'GCA', 'Age']

    features_aerial_duels = selected_columns  # Dla Aerial_Duels_M używamy wszystkich wybranych kolumn

    # Modele do załadowania
    models_with_features = {
        'Finishing_Efficiency_M': ('Player_stats_models/Finishing_Efficiency_M_rf_model.pkl', features_finishing),
        'Goals_M': ('Player_stats_models/Goals_M_rf_model.pkl', features_goals),
        'Assists_M': ('Player_stats_models/Assists_M_rf_model.pkl', features_assists),
        'Aerial_Duels_M': ('Player_stats_models/Aerial_Duels_M_rf_model.pkl', features_aerial_duels)
    }

    models_without_features = {
        'Chance_Creation_M': 'Player_stats_models/Chance_Creation_M_rf_model.pkl',
        'Goal_Creation_M': 'Player_stats_models/Goal_Creation_M_rf_model.pkl',
        'Defensive_Actions_M': 'Player_stats_models/Defensive_Actions_M_rf_model.pkl',
        'Dribbles_M': 'Player_stats_models/Dribbles_M_rf_model.pkl',
        'Deep_Progression_M': 'Player_stats_models/Deep_Progression_M_rf_model.pkl',
        'Fouls_Won_M': 'Player_stats_models/Fouls_Won_M_rf_model.pkl',
        'Aggressiveness_M': 'Player_stats_models/Aggressiveness_M_rf_model.pkl',
        'Pressure_M': 'Player_stats_models/Pressure_M_rf_model.pkl'
    }

    predictions = {}
    # Przeprowadzenie predykcji dla każdej metryki z cechami
    for metric, (model_path, feature_columns) in models_with_features.items():
        model = joblib.load(model_path)
        # Wybranie odpowiednich cech
        player_data_filtered = player_data_selected[feature_columns]
        # Skalowanie cech
        scaler = StandardScaler()
        player_data_scaled = scaler.fit_transform(player_data_filtered)
        prediction = model.predict(player_data_scaled)
        predictions[metric] = round(prediction[0], 2)

    # Przeprowadzenie predykcji dla dodatkowych metryk bez cech
    for metric, model_path in models_without_features.items():
        model = joblib.load(model_path)
        prediction = model.predict(player_data_selected)
        predictions[metric] = round(prediction[0], 2)

    # Filtracja danych dla przeciętnego zawodnika na tej samej pozycji w tym samym sezonie
    position = player_data.iloc[0]['Pos']
    league_data = df[(df['Pos'] == position) & (df['season'] == prediction_year)]
    league_avg_values = {metric: round(league_data[metric].mean(), 2) for metric in predictions.keys()}

    return predictions, league_avg_values, position

def render_stats_predict_tab():
    st.header("Przewidywanie statystyk (2024-2025)")

    # Wczytanie danych
    df = load_data()
    players = df['name'].unique()

    # Wybór zawodnika
    selected_player = st.selectbox("Wybierz zawodnika", players)

    selected_season = "2024-2025"

    metric_translation = {
        'Deep_Progression_M': 'Głęboka progresja',
        'Fouls_Won_M': 'Wywalczone faule',
        'Finishing_Efficiency_M': 'Skuteczność wykończenia',
        'Chance_Creation_M': 'Tworzenie szans',
        'Goal_Creation_M': 'Tworzenie akcji bramkowych',
        'Goals_M': 'Bramki',
        'Assists_M': 'Asysty',
        'Aerial_Duels_M': 'Pojedynki powietrzne',
        'Defensive_Actions_M': 'Akcje obronne',
        'Aggressiveness_M': 'Agresywność',
        'Dribbles_M': 'Dryblingi',
        'Pressure_M': 'Pressing'
    }

    if st.button("Przewiduj statystyki"):
        predictions, league_avg_values, position = predict_stats(selected_player, selected_season)
        if predictions:
            # Tworzymy DataFrame z przewidywanymi statystykami
            df_predictions = pd.DataFrame(predictions.items(), columns=["Statystyka", "Wartość"])
            df_predictions["Statystyka"] = df_predictions["Statystyka"].apply(lambda x: metric_translation.get(x, x))
            # Tworzymy rozwijane menu dla całej sekcji "Przewidywane statystyki"
            with st.expander("Przewidywane metryki:"):
                # Iterujemy po DataFrame i wyświetlamy statystyki oraz ich wartości
                for index, row in df_predictions.iterrows():
                    st.write(f"**{row['Statystyka']}:** {row['Wartość']}")



            st.subheader("Wykres radarowy:")
            metrics = list(predictions.keys())
            player_values = list(predictions.values())
            league_avg_values_list = list(league_avg_values.values())

            # Dodanie wartości zamykającej
            player_values += player_values[:1]
            league_avg_values_list += league_avg_values_list[:1]

            plot_radar_chart_without_average(player_values, metrics, metric_translation, selected_player, selected_season)
