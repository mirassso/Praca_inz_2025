import streamlit as st
import pandas as pd
import unicodedata
from other.player_radar_chart import get_player_and_league_data, plot_radar_chart

@st.cache_data
def load_data():
    try:
        return pd.read_csv('merged_players.csv', sep=',')
    except Exception as e:
        st.error(f"Nie udało się wczytać danych: {e}")
        return None

def normalize_string(s):
    return unicodedata.normalize('NFKD', s).encode('ASCII', 'ignore').decode('ASCII')

def map_position(position):
    pos_mapping = {
        'MF': 'Pomocnik',
        'FW': 'Napastnik',
        'DF': 'Obrońca'
    }
    return '/'.join([pos_mapping[pos] for pos in (position[i:i+2] for i in range(0, len(position), 2)) if pos in pos_mapping])

def render_stats_tab():
    data = load_data()
    if data is None:
        st.stop()

    st.header("Statystyki zawodników")

    # Pobranie listy unikalnych zawodników
    players = data['name'].unique()

    # Wybór zawodnika z menu rozwijalnego
    selected_player_name = st.selectbox("Wybierz zawodnika:", players)

    if selected_player_name:
        # Filtracja danych po wybranym zawodniku
        player_data = data[data['name'] == selected_player_name]
        
        # Sprawdź liczbę dostępnych sezonów
        available_seasons = player_data['season'].unique()
        if len(available_seasons) > 1:
            selected_season = st.selectbox("Wybierz sezon:", available_seasons)
            player_data = player_data[player_data['season'] == selected_season]
        else:
            selected_season = available_seasons[0]  # Jedyny dostępny sezon

        # Pobierz dane wybranego sezonu i zawodnika
        selected_player_data = player_data.iloc[0]

        st.header(f"{selected_player_data['name']}")


        # Utwórz dwie kolumny
        col1, col2 = st.columns([2, 1])  # Proporcja szerokości kolumn (2:1)

        # Wyświetl informacje o zawodniku w lewej kolumnie
        with col1:
            st.subheader("Informacje o zawodniku")
            st.write(f"Sezon: {selected_season}")
            st.write(f"Pozycja: {map_position(selected_player_data['Pos'])}")
            st.write(f"Liga: {selected_player_data['Comp']}")
            st.write(f"Narodowość: {selected_player_data['Nation']}")
            st.write(f"Wiek: {selected_player_data['Age']} lat")

        # Wyświetl zdjęcie zawodnika w prawej kolumnie
        with col2:
            if 'image_url' in selected_player_data and pd.notna(selected_player_data['image_url']):
                st.image(
                    selected_player_data['image_url'],
                    caption=selected_player_data['name'],
                    use_column_width=True
                )
            else:
                st.warning("Brak zdjęcia zawodnika.")

        
        # Kluczowe statystyki
        stats = {
            "Liczba minut w sezonie": "Min",
            "Liczba goli": "Goals",
            "Liczba strzałów": "Shots",
            "Procent strzałów celnych": "SoT%",
            "Gole na strzał": "G/Sh",
            "Śr. odległość strzałów": "ShoDist",
            "Asysty": "Assists",
            "Procent celnych podań": "PasTotCmp%",
            "Procent celnych krótkich podań": "PasShoCmp%",
            "Procent celnych średnich podań": "PasMedCmp%",
            "Procent celnych długich podań": "PasLonCmp%",
            "Dryblingi": "DriAtt",
            "Udane dryblingi": "DriSucc",
            "Akcje tworzące bramkę": "GCA",
            "Dośrodkowania": "CrsPA",
            "Biegi progresywne": "CarProg",
            "Kontakty z piłką": "Touches",
            "Faule popełnione na zawodniku": "Fld",
            "Spalone": "Off",
            "Odbiory": "Rec",
            "Udane przechwyty": "Int",
            "Faule": "Fls",
            "Żółte kartki": "CrdY",
            "Czerwone kartki": "CrdR",
            "Wygrane pojedynki powietrzne": "AerWon"
        }

        with st.expander("### Szczegółowe statystyki zawodnika"):
            for display_name, column_name in stats.items():
                if column_name in selected_player_data:
                    st.write(f"{display_name}: {selected_player_data[column_name]}")

        # Generowanie wykresu radarowego
        player_values, league_avg_values, metrics, metrics_mapping, player_minutes, league_avg_minutes = get_player_and_league_data(data, selected_player_name, selected_season)
        plot_radar_chart(player_values, league_avg_values, metrics, metrics_mapping, selected_player_name, selected_season)

        # Tworzenie tabeli z wartościami metryk dla zawodnika i średniego zawodnika w tej samej lidze
        table_columns = [selected_player_name] + [metrics_mapping[metric] for metric in metrics] + ["Minuty"]
        player_row = [selected_player_name] + [round(value, 2) for value in player_values[:-1]] + [player_minutes]
        league_avg_row = ["Przeciętny zawodnik"] + [round(value, 2) for value in league_avg_values[:-1]] + [league_avg_minutes]

        table_data = [player_row, league_avg_row]
        table_df = pd.DataFrame(table_data, columns=table_columns)

        st.dataframe(table_df)
    else:
        st.write("Nie wybrano zawodnika.")
