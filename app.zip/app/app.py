import streamlit as st
from tabs.search_tab import render_search_tab
from tabs.stats_tab import render_stats_tab
from tabs.team_style_tab import render_teams_style_tab
from tabs.stats_predict_tab import render_stats_predict_tab
from tabs.team_fit_tab import render_team_fit_tab

st.set_page_config(page_title="Ocena potencjalnych transferów piłkarskich", page_icon="⚽")

# Tytuł
st.title("Ocena potencjalnych transferów piłkarskich ⚽")

# Zakładki
tabs = st.tabs(["Wyszukiwanie", "Statystyki", "Styl gry zespołu", "Przewidywanie statystyk", "Ocena dopasowania do zespołu" ])

with tabs[0]:
    render_search_tab()

with tabs[1]:
    render_stats_tab()

with tabs[2]:
    render_teams_style_tab()

with tabs[3]:
    render_stats_predict_tab()

with tabs[4]:
    render_team_fit_tab()

    