import streamlit as st
import matplotlib.pyplot as plt
from math import pi

def get_player_and_league_data(data, player_name, season):
    # Lista metryk do wykresu radarowego
    metrics = ['Deep_Progression_M', 'Fouls_Won_M', 'Finishing_Efficiency_M', 'Chance_Creation_M', 
               'Goal_Creation_M', 'Goals_M', 'Assists_M', 'Aerial_Duels_M', 
               'Defensive_Actions_M', 'Aggressiveness_M', 'Dribbles_M', 'Pressure_M']

    # Mapowanie nazw metryk na język polski
    metrics_mapping = {
        'Deep_Progression_M': 'Głęboka progresja',
        'Fouls_Won_M': 'Wywalczone faule',
        'Finishing_Efficiency_M': 'Skuteczność wykończenia',
        'Chance_Creation_M': 'Tworzenie szans',
        'Goal_Creation_M': 'Tworzenie akcji bramkowych',
        'Goals_M': 'Bramki',
        'Assists_M': 'Asysty',
        'Aerial_Duels_M': 'Pojedynki powietrzne',
        'Defensive_Actions_M': 'Akcje obronne',
        'Aggressiveness_M': 'Agresywność',
        'Dribbles_M': 'Dryblingi',
        'Pressure_M': 'Pressing'
    }

    # Filtracja danych dla wybranego zawodnika w danym sezonie
    player_data = data[(data['name'] == player_name) & (data['season'] == season)]

    # Filtracja danych dla średniego zawodnika w tej samej lidze, pozycji, sezonie i obliczenie wartości metryk (mean)
    league_data = data[(data['Comp'] == player_data.iloc[0]['Comp']) & 
                       (data['Pos'] == player_data.iloc[0]['Pos']) &
                       (data['season'] == season)]
    league_avg_data = league_data[metrics].mean()

    # Wartości metryk dla wybranego zawodnika
    player_values = player_data[metrics].values.flatten().tolist()

    # Wartości metryk dla średniego zawodnika w tej samej lidze, pozycji i sezonie
    league_avg_values = league_avg_data.values.flatten().tolist()

    # Dodanie pierwszej wartości na koniec listy, aby zamknąć wykres radarowy
    player_values += player_values[:1]
    league_avg_values += league_avg_values[:1]

    # Dodanie liczby minut (Min) do wyników
    player_minutes = player_data['Min'].values[0]
    league_avg_minutes = league_data['Min'].mean().round()
    
    return player_values, league_avg_values, metrics, metrics_mapping, player_minutes, league_avg_minutes

def plot_radar_chart(player_values, league_avg_values, metrics, metrics_mapping, player_name, season):
    # Ilość zmiennych
    num_vars = len(metrics)

    # Ustawienia wykresu radarowego
    angles = [n / float(num_vars) * 2 * pi for n in range(num_vars)]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(polar=True))

    # Rysowanie wykresu dla zawodnika
    ax.plot(angles, player_values, linewidth=1, linestyle='solid', label=f'{player_name} ({season})', color='green')
    ax.fill(angles, player_values, 'green', alpha=0.3)

    # Rysowanie wykresu dla średniego zawodnika w tej samej lidze
    ax.plot(angles, league_avg_values, linewidth=1, linestyle='solid', label=f'Średnia ({season})', color='black', alpha=0.5)
    ax.fill(angles, league_avg_values, 'black', alpha=0.2)

    # Dodanie etykiet metryk
    translated_metrics = [metrics_mapping[metric] for metric in metrics]
    plt.xticks(angles[:-1], translated_metrics, color='black', size=12, weight='bold')

    # Ustawienia dla okręgów pomocniczych
    ax.set_rscale('linear')
    ax.set_ylim(0, 10)
    ax.set_yticks([1, 2, 3, 4, 5, 6, 7, 8, 9])
    ax.set_yticklabels([])

    # Dodanie tytułu i legendy
    plt.title(f'{player_name} ({season})', size=20, color='green', y=1.1)
    ax.legend(loc='upper right', bbox_to_anchor=(0.1, 0.1))

    # Wyświetlenie wykresu przy użyciu Streamlit
    st.pyplot(fig)

def plot_radar_chart_without_average(player_values, metrics, metrics_mapping, player_name, season):
    # Ilość zmiennych
    num_vars = len(metrics)

    # Ustawienia wykresu radarowego
    angles = [n / float(num_vars) * 2 * pi for n in range(num_vars)]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(polar=True))

    # Rysowanie wykresu dla zawodnika
    ax.plot(angles, player_values, linewidth=1, linestyle='solid', label=f'{player_name} ({season})', color='green')
    ax.fill(angles, player_values, 'green', alpha=0.3)

    # Dodanie etykiet metryk
    translated_metrics = [metrics_mapping[metric] for metric in metrics]
    plt.xticks(angles[:-1], translated_metrics, color='black', size=12, weight='bold')

    # Ustawienia dla okręgów pomocniczych
    ax.set_rscale('linear')
    ax.set_ylim(0, 10)
    ax.set_yticks([1, 2, 3, 4, 5, 6, 7, 8, 9])
    ax.set_yticklabels([])

    # Dodanie tytułu i legendy
    plt.title(f'{player_name} ({season})', size=20, color='green', y=1.1)
    ax.legend(loc='upper right', bbox_to_anchor=(0.1, 0.1))

    # Wyświetlenie wykresu przy użyciu Streamlit
    st.pyplot(fig)

def plot_radar_chart_team_fit(player_name, season, scaled_predictions, metrics_mapping_2):

    # Przygotowanie danych
    metrics = list(scaled_predictions.keys())
    player_values = list(scaled_predictions.values())
    
    # Dodanie pierwszej wartości na koniec, aby zamknąć wykres
    player_values += player_values[:1]  # Zamknięcie wykresu
    translated_metrics = [metrics_mapping_2.get(metric, metric) for metric in metrics]
    
    # Ilość zmiennych
    num_vars = len(metrics)
    
    # Kąty dla metryk
    angles = [n / float(num_vars) * 2 * pi for n in range(num_vars)]
    angles += angles[:1]  # Zamknięcie kąta
    
    # Tworzenie wykresu radarowego
    fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(polar=True))
    
    # Rysowanie wykresu dla zawodnika
    ax.plot(angles, player_values, linewidth=2, linestyle='solid', label=f'{player_name} ({season})', color='green')
    ax.fill(angles, player_values, 'green', alpha=0.3)
    
    # Ustawienia osi i etykiet
    plt.xticks(angles[:-1], translated_metrics, color='black', size=12, weight='bold')  # Poprawne zamknięcie
    ax.set_rscale('linear')
    ax.set_ylim(0, 10)
    ax.set_yticks([1, 2, 3, 4, 5, 6, 7, 8, 9])
    ax.set_yticklabels([])
    
    # Tytuł i legenda
    plt.title(f'{player_name} ({season})', size=20, color='green', y=1.1)
    ax.legend(loc='upper right', bbox_to_anchor=(1.2, 1.1))
    
    # Wyświetlenie wykresu w Streamlit
    st.pyplot(fig)
